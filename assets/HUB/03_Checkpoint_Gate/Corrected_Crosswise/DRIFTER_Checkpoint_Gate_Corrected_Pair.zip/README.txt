DRIFTER — Corrected checkpoint gate states

Both sprites use the same 1536x1024 scene and magenta key background.
LOWERED: the boom runs crosswise across the lane and rests at the far-side support.
RAISED: the same boom pivots upward from the same control post, leaving the lane clear.
The raised version is a composited edit of the lowered scene to keep the booth, road, posts and surroundings aligned.
